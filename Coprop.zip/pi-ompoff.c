/*#include <stdlib.h>
#include <stdio.h>
#include <omp.h>
#include <time.h>
#include<math.h>

#define MAX_INTERVALS 33554432 // 2^25

int main(int argc, char **argv) {
    if (argc < 2) {
        printf("Falta número de intervalos\n");
        exit(-1);
    }

    int intervals = atoi(argv[1]);
    if (intervals < 1) {
        intervals = 1E6;
        printf("Intervalos = %d\n", intervals);
    }

    double sum = 0.0;
    double width = 1.0 / intervals;
    double start_time, end_time;

    start_time = omp_get_wtime();

#pragma omp target teams distribute parallel for reduction(+:sum)
    for (int i = 0; i < intervals; i++) {
        double x = (i + 0.5) * width;
        sum += 4.0 / (1.0 + x * x);
    }

    end_time = omp_get_wtime();

    double pi = sum * width;
    printf("PI calculado: %26.24f\n", pi);
    printf("Tiempo de cálculo en GPU: %f segundos\n", end_time - start_time);
    printf("Error cometido: %.10f\n",fabs(pi-M_PI));

    return 0;
}*/
#include <stdlib.h>
#include <stdio.h>
#include <omp.h>
#include <time.h>
#include <math.h>

#define MAX_INTERVALS 33554432 // 2^25

int main(int argc, char **argv) {
    if (argc < 2) {
        printf("Falta número de intervalos\n");
        exit(-1);
    }

    int intervals = atoi(argv[1]);
    if (intervals < 1) {
        intervals = 1E6;
        printf("Intervalos = %d\n", intervals);
    }

    double sum = 0.0;
    double width = 1.0 / intervals;
    double start_time, end_time, start_transfer_time, end_transfer_time;

    // Mark the start of CPU-GPU transfer
    start_transfer_time = omp_get_wtime();

    // Transfer data from CPU to GPU
    #pragma omp target enter data map(to:sum, width, intervals)

    // Mark the end of CPU-GPU transfer
    end_transfer_time = omp_get_wtime();
    printf("Tiempo de transferencia CPU a GPU: %f segundos\n", end_transfer_time - start_transfer_time);

    start_time = omp_get_wtime();

    #pragma omp target teams distribute parallel for reduction(+:sum)
    for (int i = 0; i < intervals; i++) {
        double x = (i + 0.5) * width;
        sum += 4.0 / (1.0 + x * x);
    }

    end_time = omp_get_wtime();

    // Mark the start of GPU-CPU transfer
    start_transfer_time = omp_get_wtime();

    // Transfer data from GPU to CPU
    #pragma omp target exit data map(from:sum)

    // Mark the end of GPU-CPU transfer
    end_transfer_time = omp_get_wtime();
    printf("Tiempo de transferencia GPU a CPU: %f segundos\n", end_transfer_time - start_transfer_time);

    double pi = sum * width;
    printf("PI calculado: %26.24f\n", pi);
    printf("Tiempo de cálculo en GPU: %f segundos\n", end_time - start_time);
    printf("Error cometido: %.100f\n", fabs(pi - M_PI));

    return 0;
}

